<?php
chdir ('..');
require_once 'init.php';

error_reporting(E_ALL & ~E_STRICT & ~E_WARNING & ~E_NOTICE);
ini_set('display_errors',1);

require_once 'html2pdf_v4.01/html2pdf.class.php';

$html = '<style type="text/css">
<!--
table {
	width: 100%;
}

td {
	text-align: justify;
	vertical-align: top;
	padding-top: 10px;
	width: 100%;
}

.header {
	vertical-align: middle;
	position: absolute;
	width: 100%;
	height: 27mm;
	left: 0pt;
	right: 0pt;
	top: 0pt;
	background: none repeat scroll 0% 0% rgb(162, 0, 0);
}

.headerText {
	font-size: 16pt;
	font-weight: bold;
	font-family: arial, sans-serif;
	color: #FFFFFF;
	margin-left: 20mm;
}

.content {
	margin-left: 0mm;
	margin-right: 30mm;
	margin-bottom: 0mm;
}

.footer {
	margin-left: 20mm;
	margin-right: 30mm;
	margin-bottom: 10mm;
	font-size: 9pt;
	font-weight: bold;
	font-family: arial, sans-serif;
	color: #000000;
}

h1 {
	font-size: 14pt;
	font-family: arial, sans-serif;
	color: #000000;
}

h2 {
	font-size: 12pt;
	color: #000000;
}

h3 {
	font-size: 11pt;
	color: #000000;
}
-->
</style>


<page backtop="30mm" backleft="20mm" backbottom="20mm" backright="30mm">
<page_header>
<div class="header">
	<span class="headerText">Projektdokumentation</span>
</div>
</page_header> <page_footer>
<div class="footer">
	<table style="width: 100%;">
		<tr>
			<td style="text-align: left; width: 50%"><b><i>Mädchen
						wählen Technik</i> – Projektdokumentation </b></td>

			<td style="text-align: right; width: 50%">[[page_cu]]/{nb}</td>
		</tr>
	</table>
</div>
</page_footer>
<div class="content">
	<table>
		<col style="width: 35%" class="col1">
		<col style="width: 65%" class="col2">
		<tr>
			<td width="100%"><img
				src="/var/www/ftppfs01/partner-fuer-schule/live/intern/images/logos/mwt.png" />

			</td>
		</tr>
		<tr>
			<td width="100%">
				<h1>Schubiduh</h1>
				<br /></td>
		</tr>
		<tr>
			<td width="100%">
				<h2>1. Projektdaten</h2></td>
		</tr>
		<tr>
			<td width="100%">

				<h3>Schulnummer</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">987654</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Schulname</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">Meierschule</td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Schulform</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">Grundschulen</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Postleitzahl / Ort</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">01099 / Leipzig</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Webseite</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">www.test.de</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Durchführungszeitraum</h3>
			</td>
		</tr>

		<tr>
			<td width="100%">04.11.2010 - 28.02.2011</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Duchgeführt in Klasse/Jahrgangsstufe</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">1</td>
		</tr>
		<tr>
			<td width="100%">

				<h3>Wurde Ihr Projekt koedukativ durchgeführt?</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Handelt es sich um ein einmaliges Konzept oder um ein
					Angebot, welches Teil des regulären Schulunterrichts sein wird?</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">Noch offen</td>
		</tr>

	</table>

	<br />
	<table>
		<col style="width: 35%" class="col1">
		<col style="width: 65%" class="col2">
		<tr>
			<td width="100%">
				<h3>Wieviele Sch&uuml;lerinnen und Sch&uuml;ler haben
					teilgenommen?</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Anzahl Schüler/innen gesamt (Jungen und Mädchen)</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">24</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>davon Schülerinnen</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">12</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>davon teilnehmende Schülerinnen mit Zuwanderungsgeschichte</h3>
			</td>
		</tr>

		<tr>
			<td width="100%">4</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>In welchem Rahmen haben Sie das Projekt durchgeführt?</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">Unterrichtseinheit, im Fach: Sachunterricht,
				Mathematik, Deutsch, Kunst<br />
			</td>
		</tr>
		<tr>
			<td width="100%">

				<h3>Haben Sie das Projekt in einem Lehrer/innen-Tandem
					durchgeführt?</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">Nein</td>
		</tr>
		<tr>
			<td width="100%"></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Seit wann sind die beteiligten Lehrkr&auml;fte im
					Schuldienst t&auml;tig?</h3>
			</td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Lehrkraft 1</h3>
			</td>
		</tr>
		<tr>
			<td width="100%"></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Jahre im Schuldienst (Lehrkraft 1)</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">8</td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Lehramtsanwärter/in (Lehrkraft 1)</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">Nein</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Geschlecht (Lehrkraft 1)</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">männlich</td>
		</tr>
		<tr>
			<td width="100%"></td>
		</tr>


	</table>
	<!--2. Projektbeschreibung  -->
	<table>
		<col style="width: 35%" class="col1">
		<col style="width: 65%" class="col2">
		<tr>
			<td width="100%">
				<h2>2. Projektbeschreibung</h2></td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Bitte beschreiben Sie Ihr Projekt zusammenfassend in
					einigen Sätzen (max. 3500 Zeichen):</h3></td>
		</tr>
		<tr>
			<td width="100%">Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Was haben Sie konkret gemacht, um Ihre Projektziele im
					Bereich der Mädchen-MINTFörderung zu erreichen? (max. 3500 Zeichen)</h3>
			</td>
		</tr>
		<tr>
			<td width="100%">Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet.</td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Welche Quellen (Internetseiten, Literatur) haben Sie zur
					Unterstützung benutzt?</h3></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Literatur (max. 3500 Zeichen)</h3></td>
		</tr>
		<tr>
			<td width="100%">Richtlinien und Lehrpläne für die Grundschule
				in Nordrhein-Westfalen. Herausgegeben vom Ministerium für Schule und
				Weiterbildung des Landes Nordrhein-Westfalen. Heft 2010</td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Internetquellen (max. 3500 Zeichen)</h3></td>
		</tr>
		<tr>
			<td width="100%">Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>In welcher Form haben Sie das Schulprogramm berücksichtigt
					und/oder erweitert?</h3></td>
		</tr>
		<tr>
			<td width="100%">Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br>
			</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Inwieweit berücksichtigt Ihre Lerneinheit das Konzept der
					individuellen Förderung?</h3></td>
		</tr>
		<tr>
			<td width="100%">sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet.</td>
		</tr>
	</table>
	<br />
	<!--3. Rahmenbedingungen  -->

	<table>
		<col style="width: 35%" class="col1">
		<col style="width: 65%" class="col2">
		<tr>
			<td width="100%">
				<h2>3. Rahmenbedingungen</h2></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Welche Rahmenbedingungen haben Sie in Ihrer Schule
					vorgefunden hinsichtlich räumlicher Ausstattung und vorhandener
					Geräte? (max. 1750 Zeichen)</h3></td>
		</tr>
		<tr>
			<td width="100%">Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>MINT-Erfahrungen</h3></td>
		</tr>
		<tr>
			<td width="100%">Mädchen wählen Technik, Laufzeit 2010 – 2012,
				im: 1. Halbjahr 2010/2011<br />Erfahrung in beiden Bereichen
				(MINT-Förderung und Mädchen-MINT-Förderung)<br />Mädchen wählen
				Technik, Laufzeit 2007/2008<br /></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Ist Geschlechtergerechtigkeit in Ihrem Schulprogramm
					verankert?</h3></td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Gibt es Konferenzbeschlüsse zur Geschlechtergerechtigkeit
					an der Schule?</h3></td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Gibt es Partner/innen, mit denen diesbezüglich
					zusammengearbeitet wird?</h3></td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Ist die MINT-Förderung in Ihrem Schulprogramm verankert?</h3></td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Gibt es Konferenzbeschlüsse zur MINT-Förderung?</h3></td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Gibt es Partner/innen, mit denen diesbezüglich
					zusammengearbeitet wird?</h3></td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Partner/innen bei der Durchführung</h3></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Haben Sie im Verlauf des Projekts in irgendeiner Weise mit
					Partner/innen eng zusammengearbeitet?</h3></td>
		</tr>
		<tr>
			<td width="100%">Nein<br /></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Bitte beschreiben Sie kurz die Zusammenarbeit:</h3></td>
		</tr>
		<tr>
			<td width="100%"></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Außerschulische Lernorte</h3></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Haben Sie außerschulische Lernorte besucht?</h3></td>
		</tr>
		<tr>
			<td width="100%">Nein</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Bitte beschreiben Sie kurz, welche das waren und wie Ihr
					Aufenthalt dort aussah (max 1750 Zeichen):</h3></td>
		</tr>
		<tr>
			<td width="100%"></td>
		</tr>
	</table>
	<br />
	<!--4. Erfahrungen und Ergebnisse  -->

	<table>
		<col style="width: 35%" class="col1">
		<col style="width: 65%" class="col2">
		<tr>
			<td width="100%">
				<h2>4. Erfahrungen und Ergebnisse</h2></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Bitte reflektieren Sie nach der Durchführung Ihres Projekts
					hier Ihre Erfahrungen:</h3></td>
		</tr>
		<tr>
			<td width="100%">Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Planen Sie Ihre Lerneinheit evtl. auszubauen?</h3></td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Wenn ja, wie?</h3></td>
		</tr>
		<tr>
			<td width="100%">Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Bitte geben Sie an, welche Auswirkungen das Projekt in
					folgenden Bereichen hatte:</h3></td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Wurden fachrelevante Kompetenzen im Projekt erworben?</h3></td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Wenn ja, welche?</h3></td>
		</tr>
		<tr>
			<td width="100%"></td>
		</tr>
		Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam
		nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat,
		sed diam voluptua. At vero eos et accusam et justo duo dolores et ea
		rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem
		ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur
		sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
		dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam
		et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea
		takimata sanctus est Lorem ipsum dolor sit amet.
		<br> Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
		diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam
		erat, sed diam voluptua. At vero eos et accusam et justo duo dolores
		et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est
		Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur
		sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
		dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam
		et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea
		takimata sanctus est Lorem ipsum dolor sit amet.
		<br> Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
		diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam
		erat, sed diam voluptua. At vero eos et accusam et justo duo dolores
		et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est
		Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur
		sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
		dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam
		et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea
		takimata sanctus est Lorem ipsum dolor sit amet.
		<br>
		<tr>
			<td width="100%">
				<h3>Haben sich Interesse und Motivation der Mädchen durch das
					Projekt im MINT-Bereich verändert?</h3></td>
		</tr>
		<tr>
			<td width="100%">Ja</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Wenn ja, inwiefern?</h3></td>
		</tr>
		<tr>
			<td width="100%">sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
        et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
        no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
        dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
        voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
        Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
        dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
        sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
        et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
        no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
        dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
        voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
        Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
        dolor sit amet. <br> Lorem ipsum dolor sit amet, </td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Haben sich Einstellung und Haltung der am Projekt
					beteiligten Lehrkräfte verändert?</h3></td>
		</tr>

		<tr>
			<td width="100%">Ja</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Wenn ja, in welcher Weise?</h3></td>
		</tr>
		<tr>
			<td width="100%">sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
        et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
        no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
        dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
        voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
        Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
        dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
        sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
        et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
        no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
        dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
        voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
        Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
        dolor sit amet. <br> Lorem ipsum dolor sit amet, </td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Bemerkungen (max 1750 Zeichen):</h3></td>
		</tr>
		<tr>
			<td width="100%">Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet.</td>
		</tr>
		<tr>
			<td width="100%">
				<h3>Das Autoren- und Autorinnenteam (max. 1750 Zeichen)</h3></td>
		</tr>
		<tr>
			<td width="100%">Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. <br> Lorem ipsum dolor sit amet, consetetur
				sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
				et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
				accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
				no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum
				dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
				tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
				voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
				Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum
				dolor sit amet. 
			</td>
		</tr>

		<tr>
			<td width="100%">
				<h3>Ansprechpartner/in</h3></td>
		</tr>
		<tr>
			<td width="100%">Martin Gerste</td>
		</tr>
	</table>
	<h2>Projektfotos</h2>
	<table>
		<col style="width: 35%" class="col1">
		<col style="width: 65%" class="col2">
		<tr>
			<th>Link</th>
			<th>Details</th>
		</tr>
		<tr>
			<td><a href="" target="_blank"><img src=""/></a><b>Titel</b>
					<br />
				<br /> Bild 1<br />
				<br /> <b>Beschreibung</b> <br />
				<br /> Die Stirnseite eines Lotusan-Hauses entsteht 
			</td>
		</tr>
		<tr>
			<td><b>Titel</b> <br />
			<br /> Bild 2<br />
			<br /> <b>Beschreibung</b> <br />
			<br /> Testvorrichtung Lotusanhäuser</td>
		</tr>
		<tr>
			<td><a href="" target="_blank"><img src=""/></a><b>Titel</b>
					<br />
				<br /> Bild 3<br />
				<br /> <b>Beschreibung</b> <br />
				<br /> Gabriela erkundet Fischflosse 
			</td>
		</tr>
		<tr>
			<td><a href="" target="_blank"><img src=""/></a><b>Titel</b>
					<br />
				<br /> Bild 4<br />
				<br /> <b>Beschreibung</b> <br />
				<br /> Unsere Werkbank 
			</td>
		</tr>
		<tr>
			<td><a href="" target="_blank"><img src=""/></a><b>Titel</b>
					<br />
				<br /> Bild 5<br />
				<br /> <b>Beschreibung</b> <br />
				<br /> Lotusanhäuser usw. 
			</td>
		</tr>
	</table>
	<h2>Projektdokumente</h2>
	<p>Noch keine Projektdokumente vorhanden.</p>
	<br />
	<table>
		<col style="width: 35%" class="col1">
		<col style="width: 65%" class="col2">
		<tr>
			<td width="100%">Diese Lerneinheit/Unterrichtsreihe wurde im
				Rahmen des Projekts <b>Mädchen wählen Technik</b> entwickelt. Das
				Urheberrecht liegt bei den angegebenen Autoren/Autorinnen.</td>
		</tr>

		<tr>
			<td width="100%"><img
				src="/var/www/ftppfs01/partner-fuer-schule/live/intern/images/projects/mwt/Logofuss-mwt.jpg"
				width="600px;" /></td>
		</tr>
	</table>
</div>
</page>';
$html2pdf = new HTML2PDF( 'P', 'A4', 'en', true ,'UTF-8', array(0, 0, 0, 0));
$html2pdf->setTestTdInOnePage(true);
//don't test if images are present, because of fatal error
$html2pdf->setTestIsImage(false);
$html2pdf->WriteHTML($html);
$html2pdf->Output('EmptyPages.pdf', 'D');
?>